import { MediaSection } from "@/components/media-section"

export default function MediaPage() {
  return <MediaSection />
}
